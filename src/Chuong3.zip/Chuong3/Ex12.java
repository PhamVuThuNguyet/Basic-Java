package Chuong3;

public class Ex12 {
    public static void main(String[] args) {
        for(int i = 0; i < 5; i++){ // rows
            for(int j = 0; j < 10; j ++){ // columns
                System.out.print("* ");
            }
            System.out.println("");
        }
    }
}
