package Chuong3;

public class Ex18 {
    // 1, 7, 16, 37, 79, 173,...
    public static void main(String[] args) {

    }
}
