package Chuong3;

public class Ex21 {
    public static void main(String[] args) {
        for(int i = 0; i <= 65535; i++){
            System.out.println(Integer.toHexString(i).toUpperCase());
        }
    }
}
