package Chuong3;

public class Ex22 {
    public static void main(String[] args) {
        for(int i = 0; i <= 511; i++){
            System.out.println(Integer.toOctalString(i));
        }
    }
}
